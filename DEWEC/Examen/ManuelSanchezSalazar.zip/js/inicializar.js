var productos=[
    {id:1,descripcion:"Chirimolla",precio:130,stock:4,src:"imagenes/chirimoyo.jpg"},
    {id:2,descripcion:"Manzana",precio:70,stock:4,src:"imagenes/manzana.jpg"},
    {id:3,descripcion:"Melocoton",precio:110,stock:4,src:"imagenes/melocoton.jpg"},
    {id:4,descripcion:"platano",precio:100,stock:2,src:"imagenes/platano.jpg"},
    {id:5,descripcion:"naranja",precio:80,stock:3,src:"imagenes/naranja.jpg"}
];

var monedas=[
    {id:1,descripcion:"2€",valor:200,stock:4,src:"imagenes/2.gif"},
    {id:2,descripcion:"1€",valor:100,stock:4,src:"imagenes/1.gif"},
    {id:3,descripcion:"50 Cts",valor:50,stock:4,src:"imagenes/50.gif"},
    {id:4,descripcion:"20 Cts",valor:20,stock:5,src:"imagenes/20.gif"},
    {id:5,descripcion:"10 Cts",valor:10,stock:3,src:"imagenes/10.gif"}
];