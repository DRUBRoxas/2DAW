<footer id="footer">
    <div class="container">
        <div class="text-center">
            <small>Copyright © Departamento de Informática 2019</small>
        </div>
    </div>
</footer>